// Copyright (c) 2018 ml5
//
// This software is released under the MIT License.
// https://opensource.org/licenses/MIT

/* ===
ml5 Example
PoseNet example using p5.js
=== */

let video;
let poseNet;
let poses = [];
let canvas;
let imgbackground;
let imageface;
let image1;
let imageeye;
let imagelip;
let imagecamera;
let imagearrow;
let imagesunset;



//let imageface;
let songOne, songTwo, songThree, songFour, songFive, songSix, songSeven;
var isPlayingSong = false;
//for sun


//for the circle
var x;
var y;
var changeDirection;
//let noseX =0;
//let noseY =0;
let srcText = "Can the Body make sound?";
let words = srcText.split(" ");






function preload(){
imagebackground= loadImage('imagebackground.jpg');
imagecamera = loadImage('imagecamera.png');
imagearrow = loadImage('imagearrow.png');
image1 =loadImage('image1.jpg');
imageeye= loadImage('imageeye.png');
imagesunset=loadImage('imagesunset.png');
//songTwo=loadSound('songTwo.mp3');
//imagelip = loadImage('imagelip.png');
//imageface = loadImage('imageface.png');
songOne = loadSound('songOne.mp3');
songTwo = loadSound('songTwo.mp3');
songThree = loadSound('songThree.mp3');
songFour = loadSound('songFour.mp3');
songFive = loadSound('songFive.mp3');
songSix = loadSound('songSix.mp3');
songSeven = loadSound('songSeven.mp3');


}




function setup() {
  
canvas = createCanvas(800, 640);
  canvas.position((windowWidth -width)/2, 100);

  video = createCapture(VIDEO);
  video.hide();
  
  //video = createCapture(VIDEO);
 
  // Create a new poseNet method with a single detection
  poseNet = ml5.poseNet(video, modelReady);
  // This sets up an event that fills the global variable "poses"
  // with an array every time new poses are detected
  poseNet.on('pose', function(results) {
    poses = results;
    // console.log(poses);
  });
  // Hide the video element, and just show the canvas
  //video.hide();


  //for the moving circle
  x = 1;
  changeDirection = false;

  //songTwo.play();
    
}


function modelReady() {
  select('#status').html('Model Loaded');
}

function draw() {
  image(video, 0, 0, width, height);
  background(255, 229, 229);
  //image(imagebackground,0,0, 800, 640);
//fill(255);
  //image(imagecamera,0,0,100,100);
  //image(imagecamera,100,100,100,100);
  //image(imagecamera,0,100,100,100);
  //image(imagecamera,100,0,100,100);
  //image(imageface,0,640,150,100);
  image(imagesunset,200,0,300,300);

noStroke();
  fill(25,25,112);
  rect(0,500,800,500);


  //Wave 1  
  noFill();
  stroke (102, 255, 255);
  strokeWeight (25);
  beginShape();
vertex(0, 375);
bezierVertex(200, 500, 300, 300, 500, 375);
endShape();
  
  //Wave 3
    noFill();
  stroke (0, 153, 255);
  strokeWeight (24);
  beginShape();
vertex(0, 402);
bezierVertex(200, 500, 325, 330, 500, 402);
endShape();
  
    //Wave 5
    noFill();
  stroke (0, 102, 255);
  strokeWeight (18);
  beginShape();
vertex(0, 430);
bezierVertex(200, 500, 400, 350, 500, 430);
endShape();
  
  
  //Wave 8
  noFill();
  stroke (102, 255, 255);
  strokeWeight (25);
  beginShape();
vertex(0, 461);
bezierVertex(200, 525, 220, 390, 500, 460);
endShape();
  
    //Wave 7
    noFill();
  stroke (0, 153, 255);
  strokeWeight (24);
  beginShape();
vertex(0, 490);
bezierVertex(200, 500, 335, 400, 500, 490);
endShape();
  
      //Wave 5
    noFill();
  stroke (0, 102, 255);
  strokeWeight (40);
  beginShape();
vertex(0, 525);
bezierVertex(100, 525, 350, 450, 500, 500);
endShape();
  
  //Wave 2
    noFill();
  stroke (255);
  strokeWeight (6);
  beginShape();
vertex(0, 390);
bezierVertex(200, 495, 290, 315, 500, 390);
endShape();
  
    
  //Wave 4
    noFill();
  stroke (255);
  strokeWeight (4);
  beginShape();
vertex(0, 415);
bezierVertex(200, 515, 360, 335, 500, 415);
endShape();
  
    //Wave 6
    noFill();
  stroke (255);
  strokeWeight (6);
  beginShape();
vertex(0, 445);
bezierVertex(200, 500, 300, 380, 500, 440);
endShape();
  
    //Wave 9
    noFill();
  stroke (255);
  strokeWeight (4);
  beginShape();
vertex(0, 474);
bezierVertex(200, 500, 350, 390, 500, 474);
endShape();
  
      //Wave 11
    noFill();
  stroke (255);
  strokeWeight (6);
  beginShape();
vertex(0, 500);
bezierVertex(200, 500, 300, 420, 500, 480);
endShape();

  

  //try for the nose
   //triangle(noseX, noseY - 25, noseX - 30, noseY + 25, noseX + 30, noseY + 25);

//draw a moving circle
//circle 1
 fill(255, 167, 0);
 noStroke();
 //stroke(255,20,147);
 ellipse(x,100,100,100);
//fill(0);
 //ellipse(x,100,20,70);
  if(x>width){
    changeDirection=true}
  //if the circle passes the right side, change the direction
  //effects of direction change happen below
  else if (x<=0){
    changeDirection=false}
  //if the circle passes the left side (or becomes equal to 0)
  //changes the direction, effects are in the next if statement below
  
  if (x>=0 && changeDirection == false){
    x=x+1}
  //if x is greater than OR equal to 0, move right
  else if(changeDirection == true){
    x=x-1}

//circle 2
noStroke();
 //stroke(255,20,147);
 fill(74, 225, 252);
 ellipse(x+100,200,100,100);
//fill(0);
 //ellipse(x+100,200,20,70);
  if(x>width){
    changeDirection=true}
  //if the circle passes the right side, change the direction
  //effects of direction change happen below
  else if (x<=0){
    changeDirection=false}
  //if the circle passes the left side (or becomes equal to 0)
  //changes the direction, effects are in the next if statement below
  
  if (x>=0 && changeDirection == false){
    x=x+1}
  //if x is greater than OR equal to 0, move right
  else if(changeDirection == true){
    x=x-1}


//circle 3

    noStroke();
 //stroke(255,20,147);
 fill(244, 196, 235);
 ellipse(x+200,300,100,100);
//fill(0);
 //ellipse(x+100,200,20,70);
  if(x>width){
    changeDirection=true}
  //if the circle passes the right side, change the direction
  //effects of direction change happen below
  else if (x<=0){
    changeDirection=false}
  //if the circle passes the left side (or becomes equal to 0)
  //changes the direction, effects are in the next if statement below
  
  if (x>=0 && changeDirection == false){
    x=x+1}
  //if x is greater than OR equal to 0, move right
  else if(changeDirection == true){
    x=x-1}


  //circle 4
  noStroke();
 //stroke(255,20,147);
 fill(250, 5, 235);
 ellipse(x,400,100,100);
//fill(0);
 //ellipse(x+100,200,20,70);
  if(x>width){
    changeDirection=true}
  //if the circle passes the right side, change the direction
  //effects of direction change happen below
  else if (x<=0){
    changeDirection=false}
  //if the circle passes the left side (or becomes equal to 0)
  //changes the direction, effects are in the next if statement below
  
  if (x>=0 && changeDirection == false){
    x=x+1}
  //if x is greater than OR equal to 0, move right
  else if(changeDirection == true){
    x=x-1}



//circle 5
noStroke();
 //stroke(255,20,147);
 fill(90, 243, 151);
 ellipse(x-200,200,100,100);
//fill(0);
 //ellipse(x+100,200,20,70);
  if(x>width){
    changeDirection=true}
  //if the circle passes the right side, change the direction
  //effects of direction change happen below
  else if (x<=0){
    changeDirection=false}
  //if the circle passes the left side (or becomes equal to 0)
  //changes the direction, effects are in the next if statement below
  
  if (x>=0 && changeDirection == false){
    x=x+1}
  //if x is greater than OR equal to 0, move right
  else if(changeDirection == true){
    x=x-1}


    //circle 6

    noStroke();
 //stroke(255,20,147);
 fill(7, 11, 179);
 ellipse(x,550,100,100);
//fill(0);
 //ellipse(x+100,200,20,70);
  if(x>width){
    changeDirection=true}
  //if the circle passes the right side, change the direction
  //effects of direction change happen below
  else if (x<=0){
    changeDirection=false}
  //if the circle passes the left side (or becomes equal to 0)
  //changes the direction, effects are in the next if statement below
  
  if (x>=0 && changeDirection == false){
    x=x+1}
  //if x is greater than OR equal to 0, move right
  else if(changeDirection == true){
    x=x-1}



    //circle 7
    noStroke();
 //stroke(255,20,147);
 fill(121, 249, 129);
 ellipse(x-200,600,100,100);
//fill(0);
 //ellipse(x+100,200,20,70);
  if(x>width){
    changeDirection=true}
  //if the circle passes the right side, change the direction
  //effects of direction change happen below
  else if (x<=0){
    changeDirection=false}
  //if the circle passes the left side (or becomes equal to 0)
  //changes the direction, effects are in the next if statement below
  
  if (x>=0 && changeDirection == false){
    x=x+1}
  //if x is greater than OR equal to 0, move right
  else if(changeDirection == true){
    x=x-1}




//nose code from alison ps

 if (poses.length > 0) {    

  let nose = poses[0].pose.keypoints[0].position;


  let leftEar = poses[0].pose.keypoints[3].position;
 let rightEar = poses[0].pose.keypoints[4].position;

//stroke(255,69,0);
fill(255, 64);

 ellipse(nose.x, nose.y,
  (rightEar.x - leftEar.x)*2,
 (rightEar.x - leftEar.x)*2);
   

  //circle 1 
var d = int(dist(x, 100, nose.x, nose.y));
  if(d < 100){
    // in the circle
   songOne.play();

 }

//circle2
var d = int(dist(x+100, 200, nose.x, nose.y));
  if(d < 100){
    // in the circle
   songTwo.play();
   
  
  }

//circle 3
var d = int(dist(x+200,300, nose.x, nose.y));
  if(d < 100){
    // in the circle
   songThree.play();
   
  
  }


  //circle 4
  var d = int(dist(x,400, nose.x, nose.y));
  if(d < 100){
    // in the circle
   songFour.play();
   
  
  }


  //circle 5
var d = int(dist(x-200,200, nose.x, nose.y));
  if(d < 100){
    // in the circle
   songFive.play();
   
  
  }

  //circle 6

  var d = int(dist(x,550, nose.x, nose.y));
  if(d < 100){
    // in the circle
   songSix.play();
   
  
  }

  //circle 7
  var d = int(dist(x-200,600, nose.x, nose.y));
  if(d < 100){
    // in the circle
   songSeven.play();
   
  
  }










//words
fill(random(255),random(255),random(255));
  for (let i = 0; i < words.length; i++) {
    textSize(noise(i+frameCount*0.01+200) * 72);
    text(words[i],
         noise(i+frameCount*0.01)*width,
         noise(i+frameCount*0.01+100)*height);
  }

fill(0,255,255);
textSize(48);
  textAlign(CENTER, TOP);
  text("feels", width/2, height - frameCount % (width+48));




fill(0,255,255);
textSize(48);
  textAlign(CENTER, TOP);
  text("body", width/3, height - frameCount % (width+48));



fill(0,255,255);
textSize(48);
  textAlign(CENTER, TOP);
  text("wavy", width/1.5, height - frameCount % (width+48));
//words left to right
fill(255,105,180);
 textSize(48);
  textAlign(RIGHT, CENTER);
  text("control", frameCount % (width+textWidth("control")),
    height/2);


fill(255,105,180);
 textSize(48);
  textAlign(RIGHT, CENTER);
  text("body", frameCount % (width+textWidth("body")),
    height/1.2);


fill(255,105,180);
 textSize(48);
  textAlign(RIGHT, CENTER);
  text("is", frameCount % (width+textWidth("is")),
    height/1.5);

//words tops to bottom
fill(143,0,255);
textSize(48);
  textAlign(CENTER, BOTTOM);
  text("losing control", width/2, frameCount % (width+48));

  fill(143,0,255);
textSize(25);
  textAlign(CENTER, BOTTOM);
  text("making sounds", width/4, frameCount % (width+25));











//for bubble background

  for(let i = 0; i < 850; i+=20) {
    for(let j = 0; j < 120; j +=20) {
      
      if ( dist (nose.x, nose.y, i, j) < 10 ) {
        fill(255,0,0);
      }
      else{
        fill(135,206,250);
      }
  ellipse(i, j, 20, 20);
  }
}







} 


// var d = int(dist(x, 100, nose.x, nose.y));
//   if(d < 100){
//     // in the circle
//    //songOne.play();
//   }


  
//    //We can call both functions to draw all keypoints and the skeletons
drawKeypoints();
 drawSkeleton();




//console.log(d);


}




 ///Afunction to draw ellipses over the detected keypoints
function drawKeypoints()  {
//Loop through all the poses detected
 for (let i = 0; i < poses.length; i++) {
//For each pose detected, loop through all the keypoints
  let pose = poses[i].pose;   
  //for (let j = 0; j < pose.keypoints.length; j++) {
     // A keypoint is an object describing a body part (like rightArm or leftShoulder)
    //let keypoint = pose.keypoints[j];

    //this is to draw image on nose and ears
    let nosekeypoint =pose.keypoints[0];
    let rightearkeypoint = pose.keypoints[3];
    let leftearkeypoint= pose.keypoints[4];
//       // Only draw an ellipse is the pose probability is bigger than 0.2
//       if (keypoint.score > 0.2) {
//         fill(255, 0, 0);
        //noStroke();

    //image(image1,keypoint.position.x, keypoint.position.y, 25, 25);
    //image(image1,nosekeypoint.position.x, nosekeypoint.position.y, 25, 25
      image(imageeye,rightearkeypoint.position.x, rightearkeypoint.position.y, 30, 30);
       image(imageeye,leftearkeypoint.position.x, leftearkeypoint.position.y, 30, 30);
       //image(imagelip,nosekeypoint.position.x,(nosekeypoint.position.y+50),100, 100);
//imgage(imgage1,30,30,30,30);
//image1.position(keypoint.position.x, keypoint.position.y, 10, 10);
 //}



}
}



// A function to draw the skeletons
function drawSkeleton() {
  // Loop through all the skeletons detected
  for (let i = 0; i < poses.length; i++) {
    let skeleton = poses[i].skeleton;
    // For every skeleton, loop through all body connections
    for (let j = 0; j < skeleton.length; j++) {
      let partA = skeleton[j][0];
      let partB = skeleton[j][1];
      strokeWeight(10);
      stroke(255,255,0);
      line(partA.position.x, partA.position.y, partB.position.x, partB.position.y);
    }
  }



}
